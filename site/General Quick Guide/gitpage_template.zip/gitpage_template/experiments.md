---
layout: default
title: "Simulazioni ed esperimenti"
nav_order: 3
---

<!--
  Questa pagina raccoglie i risultati delle simulazioni o degli esperimenti.
  Puoi includere gallerie di video, immagini, tabelle e descrizioni.
  Adatta i modelli qui sotto alle tue esigenze.
-->

## Galleria di simulazioni o esperimenti

Se hai dei video o clip animati da mostrare, puoi utilizzare una griglia simile a questa. Crea una cartella `assets/video` e carica i tuoi file MP4 all’interno di sottocartelle descrittive (ad esempio `SIM01`, `SIM02`, ecc.).

```html
<h3>Esempio di galleria video</h3>
<div class="sim-grid sim-grid-3">
  <figure class="sim-item">
    <video class="sim-vid" autoplay muted loop playsinline preload="metadata">
      <source src="{{ '/assets/video/SIM01/SIM01.mp4' | relative_url }}" type="video/mp4">
    </video>
    <figcaption>Scenario 1</figcaption>
  </figure>
  <figure class="sim-item">
    <video class="sim-vid" autoplay muted loop playsinline preload="metadata">
      <source src="{{ '/assets/video/SIM02/SIM02.mp4' | relative_url }}" type="video/mp4">
    </video>
    <figcaption>Scenario 2</figcaption>
  </figure>
  <figure class="sim-item">
    <video class="sim-vid" autoplay muted loop playsinline preload="metadata">
      <source src="{{ '/assets/video/SIM03/SIM03.mp4' | relative_url }}" type="video/mp4">
    </video>
    <figcaption>Scenario 3</figcaption>
  </figure>
</div>
```

Puoi modificare la classe `sim-grid-3` in `sim-grid-2` o `sim-grid-4` a seconda del numero di colonne che desideri.

---

## Sintesi dei risultati

Racconta qui i risultati ottenuti dalle tue simulazioni o esperimenti. Utilizza tabelle e grafici se necessario, ma evita di inserire frasi troppo lunghe nelle tabelle (preferisci parole chiave o numeri). Esempio:

| Scenario | Descrizione | Esito |
|---|---|---|
| Scenario 1 | Condizioni iniziali ... | **Successo** |
| Scenario 2 | Condizioni iniziali ... | **Insuccesso** |

---

## Analisi e discussione

Commenta i risultati presentati. Quali sono i trend osservati? Quali fenomeni meritano attenzione? Evidenzia sia i successi sia le criticità riscontrate, in modo che il lettore comprenda a fondo la portata del tuo studio.

➡️ Per una discussione generale dei risultati principali, puoi creare un’ulteriore pagina o utilizzare [Discussione & risultati]( {{ '/results.html' | relative_url }} ), se decidi di attivarla.