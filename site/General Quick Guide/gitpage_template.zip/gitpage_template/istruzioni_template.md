# Guida all’utilizzo del template GitHub Pages

Questa guida ti accompagna passo passo nella personalizzazione del **template** fornito in questa cartella. Il progetto si basa su [Jekyll](https://jekyllrb.com/) con il tema *Just the Docs* e permette di creare un sito statico facilmente navigabile, ideale per presentare il report di un articolo scientifico o un progetto di ricerca.

## 1. Struttura dei file

La cartella principale contiene i seguenti file e directory:

- **`_config.yml`**: file di configurazione del sito (titolo, descrizione, url, link nel menu, ecc.).
- **`index.md`**: la homepage del sito; contiene il titolo, l’abstract e una panoramica dei contenuti.
- **`method.md`**: pagina dedicata al metodo o all’approccio utilizzato.
- **`experiments.md`**: pagina per raccogliere i risultati di simulazioni ed esperimenti.
- **`results.md`**: pagina di discussione e sintesi dei risultati (facoltativa).
- **`references.md`**: pagina con la citazione dell’articolo e altri link utili.
- **`_sass/`** e **`assets/`**: contengono il foglio di stile personalizzato, le immagini, i video e altri asset.
- **`about_prismalab.md`** in `_sass/color_schemes/`: pagina informativa su PRISMA Lab e le associazioni (mantenuta per riconoscenza).
- **`istruzioni_template.md`**: questa guida.

Puoi creare ulteriori pagine `.md` seguendo lo stesso schema, ricordandoti di inserire il front matter iniziale (tra le triple linee `---`) con i campi `layout`, `title` e `nav_order`.

## 2. Personalizzazione di `_config.yml`

Apri il file `_config.yml` per modificare:

- **Titolo e descrizione** del sito (`title`, `description`).
- **URL** e **baseurl**: sostituisci `<tuo-username>` e `<nome-del-tuo-progetto>` con il tuo nome utente GitHub e il nome del repository. Questi valori sono utilizzati da GitHub Pages per costruire correttamente i link.
- **`gh_edit_repository`**: aggiorna anche questo campo con il link al tuo repository GitHub se vuoi mostrare la voce “Edit this page on GitHub” nelle pagine del sito.
- **Logo e favicon**: se desideri utilizzare altri loghi, sostituisci i file nella cartella `assets/img` e aggiorna i percorsi dei campi `logo` e `favicon_ico`. I loghi del PRISMA Lab sono mantenuti di default per riconoscenza verso l’associazione.
- **Link nel menu** (`aux_links`): personalizza o aggiungi voci che compariranno in alto a destra (ad esempio link al tuo laboratorio, dipartimento o università).
- **Contenuto del footer** (`footer_content`): aggiorna l’indirizzo o la descrizione se necessario. Attualmente contiene le informazioni su PRISMA Lab, DIETI e l’Università di Napoli Federico II.

Salva il file dopo aver apportato le modifiche. Ricorda che eventuali errori di sintassi YAML (indentazione, due punti, ecc.) impediranno al sito di compilarsi correttamente.

## 3. Modifica dell’ordine di navigazione

Ogni pagina Markdown in questo template contiene nel front matter un campo `nav_order`. Le pagine con valori più **bassi** appaiono prima nel menu laterale. Ad esempio:

```yaml
---
layout: default
title: "Simulazioni ed esperimenti"
nav_order: 3
---
```

Per cambiare l’ordine, modifica il numero di `nav_order` in ciascuna pagina. Se aggiungi nuove pagine, assegna loro un numero che le posizioni nella posizione desiderata. Le pagine con lo stesso `nav_order` saranno ordinate alfabeticamente per titolo.

## 4. Inserire immagini e video

Per aggiungere un’immagine:

1. Copia il file nella cartella `assets/img/`.
2. All’interno di una pagina `.md`, inserisci l’immagine utilizzando la sintassi Markdown:

   ```markdown
   ![Descrizione]({{ '/assets/img/nome-file.png' | relative_url }})
   ```

Per aggiungere un video (solo file MP4):

1. Crea, se necessario, una sottocartella all’interno di `assets/video/` (ad esempio `SIM01`).
2. Copia il file `.mp4` nella sottocartella.
3. Inserisci il video nella pagina utilizzando il blocco `<video>` come nell’esempio contenuto in `experiments.md`. Ricorda di adattare il percorso:

   ```html
   <video autoplay muted loop playsinline preload="metadata">
     <source src="{{ '/assets/video/SIM01/clip.mp4' | relative_url }}" type="video/mp4">
   </video>
   ```

Puoi anche incorporare video YouTube/Vimeo utilizzando `<iframe>` oppure linkando un video esterno.

## 5. Aggiungere o rimuovere sezioni

Le pagine fornite contengono **sezioni** con titoli e divisori `---`. Puoi rimuovere intere sezioni se non ti servono, duplicarle o rinominarle. L’importante è mantenere una struttura logica che guidi il lettore. Quando crei nuove pagine, assicurati di impostare il `layout: default` e il `nav_order` appropriato.

### Esempio per creare una nuova pagina

1. Crea un nuovo file, ad esempio `conclusioni.md` nella radice del progetto.
2. Inizia il file con:

   ```markdown
   ---
   layout: default
   title: "Conclusioni"
   nav_order: 6
   ---

   ## Conclusioni

   Scrivi qui le conclusioni del tuo lavoro.
   ```

3. Salva e, se pubblichi su GitHub Pages, effettua il push sul repository: la pagina comparirà automaticamente nel menu laterale.

## 6. Pubblicazione su GitHub Pages

Per pubblicare il sito:

1. Crea un nuovo repository su GitHub e carica i file del template.
2. Vai nelle **Impostazioni** del repository → **Pages** e scegli il branch `main` (o quello che preferisci) come sorgente. Lascia la cartella `/` come root.
3. GitHub genererà il sito e ti fornirà un indirizzo `https://<tuo-username>.github.io/<nome-del-repo>/` dove potrai visualizzare il report.

In alternativa, se vuoi provare il sito in locale, dovrai installare Ruby e Jekyll e lanciare `bundle exec jekyll serve` dalla radice del progetto. Questa operazione è opzionale e non necessaria per l’utilizzo di GitHub Pages.

## 7. Personalizzazione avanzata

Se desideri modificare i colori, i font o altri aspetti estetici del sito, puoi intervenire sui file all’interno di `_sass/` e `assets/css/`. Ad esempio, la palette di colori definita dal PRISMA Lab si trova in `assets/css/color_schemes/custom.css` e `_sass/color_schemes/prismalab.scss`. Per ulteriori informazioni consulta la documentazione del tema *Just the Docs*.

## 8. Domande frequenti

- **Posso usare questo template per un progetto non legato al PRISMA Lab?** Sì, il template è generico. I loghi e le informazioni sulle associazioni sono inclusi per riconoscenza; puoi mantenerli o sostituirli rispettando eventuali linee guida del tuo istituto.
- **Come cambio la lingua del sito?** I testi forniti sono in italiano, ma sei libero di tradurre le pagine nella lingua che preferisci.
- **Dove trovo altri esempi?** Il file `experiments.md` contiene un esempio di griglia di video e tabelle; puoi usarlo come base per creare layout personalizzati.

Se incontrassi problemi o avessi bisogno di ulteriori personalizzazioni, consulta la documentazione ufficiale di Jekyll e del tema *Just the Docs* o contatta un membro esperto del tuo laboratorio.