---
layout: default
title: "Discussione & risultati"
nav_order: 4
---

<!--
  Questa pagina è facoltativa: serve per riassumere e discutere i risultati più importanti del tuo lavoro.
  Puoi eliminare o rinominare questa pagina a seconda delle tue preferenze.
-->

## Cosa dimostra il tuo lavoro

Riassumi qui ciò che il tuo studio prova o suggerisce. Indica chiaramente quali problemi affronta, quali contributi introduce e quali evidenze supportano le tue affermazioni. Specifica anche cosa **non** viene rivendicato (per evitare interpretazioni eccessive).

---

## Risultati principali

Utilizza questa sezione per mettere in evidenza i risultati più significativi. Puoi usare sottosezioni per raggruppare risultati omogenei (ad esempio, “Prestazioni”, “Analisi di sensibilità”, “Studi su hardware reale”, ecc.). Per ogni punto, riporta il dato numerico rilevante e la sua interpretazione. Esempio:

### A) Miglioramento rispetto allo stato dell’arte

- **Metriche principali:** descrivi la metrica e il valore ottenuto (es. *precisione*, *tempo medio*, *tasso di successo*).
- **Interpretazione:** spiega perché questo risultato è rilevante e cosa implica per il tuo campo di ricerca.

### B) Robustezza o sensibilità

- **Test eseguiti:** spiega come hai verificato la robustezza del metodo (rumore, variazioni di parametri, ecc.).
- **Risultati chiave:** riporta i valori numerici più importanti e discutili brevemente.

---

## Limiti e possibili miglioramenti

Ogni lavoro presenta dei limiti. Usare questa sezione per elencare in maniera onesta i punti in cui il metodo potrebbe fallire o richiedere ulteriori sviluppi. Fornisci anche idee per futuri miglioramenti o per estendere l’approccio a casi più complessi.

---

## Figure suggerite (opzionale)

Se vuoi includere figure in questa pagina, copia le immagini nella cartella `assets/img` e richiamale così:

```markdown
![Descrizione immagine]({{ '/assets/img/nome-immagine.png' | relative_url }})
```

Le figure potrebbero includere grafici comparativi, andamenti temporali o altri visualizzazioni utili per interpretare i risultati.