---
layout: default
title: "Riferimenti & link"
nav_order: 5
---

<!--
  Utilizza questa pagina per elencare le referenze bibliografiche, i link utili e le risorse collegate al tuo lavoro.
-->

## Citazione dell’articolo

Inserisci qui le informazioni bibliografiche complete del tuo articolo: titolo, autori, conferenza o rivista, anno, DOI, ecc. Se il tuo lavoro non è ancora pubblicato, puoi riportare la citazione prevista o lasciare questa sezione come promemoria.

### BibTeX (modifica i campi)

```bibtex
@article{mio_articolo,
  title   = {Titolo del tuo articolo},
  author  = {Cognome, Nome and Cognome, Nome and altri},
  journal = {Nome della rivista o conferenza},
  year    = {202X},
  doi     = {10.0000/xxxxxx},
  url     = {https://doi.org/10.0000/xxxxxx}
}
```

---

## Altre risorse

Usa l’elenco qui sotto per raggruppare link ad altre risorse pertinenti, come repository di codice, dataset, pagine web correlate o articoli citati.

- **Codice sorgente:** [link al repository](#)
- **Dataset utilizzato:** [link al dataset](#)
- **Articoli correlati:**
  - [Titolo 1](#)
  - [Titolo 2](#)

Sentiti libero di strutturare questa sezione come preferisci (elenchi, sottosezioni, ecc.).